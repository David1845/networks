package com.company;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;



class FileCalcultion {

    private String filename;
    private ArrayList<String> Data;


    FileCalcultion(String filename) {
        this.filename = filename;
        this.Data = new ArrayList<String>();
        readfile();
    }


    void readfile() {
        Scanner s = null;
        try {
            s = new Scanner(new File(filename));
            s.nextLine();
            while (s.hasNext()) {
                Data.add(s.nextLine());
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
       // System.out.println(Data);
    }


    ArrayList<employee> Parsefile() {
        ArrayList<employee> employees = new ArrayList<employee>();

        for (int DataIndex = 0; DataIndex < Data.size(); DataIndex++) {
            Scanner s = new Scanner(Data.get(DataIndex)).useDelimiter(",");
            while (s.hasNext()) {
                employees.add(new employee(s.next(), s.next(), s.next()));
            }
        }
        return employees;
    }
}


class employee {

        private String Name;
        private int Salary;
        private String Role;

        employee(String Name, String Salary, String Role) {
            this.Name = Name;
            this.Salary = CheckSalary(Salary);
            this.Role = Role;
        }


        private int CheckSalary(String Salary){
            try {
                this.Salary = Integer.parseInt(Salary);
            }catch (Exception e){
                return 0;
            }
            return this.Salary;
        }


        void display() {
            System.out.println(Name + " " + Salary + " " + Role);
        }


        String GetName(){
            return Name;
        }


        int GetSalary(){
            return Salary;
        }

        String GetRole(){
            return Role;
        }

    }


class employeeCalculations{

    private ArrayList<employee> Employees;


    employeeCalculations(String filename){
        Employees = new FileCalcultion(filename).Parsefile();
    }


    private Set<String> get_roles(){

        Set<String> Roles = new HashSet<String>();

        for(int EmployeeIndex = 0;EmployeeIndex<Employees.size();EmployeeIndex++){
            Roles.add(Employees.get(EmployeeIndex).GetRole());
        }

        return Roles;
    }


    void CalculatePayByRole(Boolean CalculateByTime){

        ArrayList<String> Roles = new ArrayList<String>();
        Roles.addAll(get_roles());


        int totalPay=0;

        for(int RoleIndex=0; RoleIndex< Roles.size(); RoleIndex++){

            for(int EmployeeIndex =0; EmployeeIndex<Employees.size();EmployeeIndex++){

               if(Roles.get(RoleIndex).equals(Employees.get(EmployeeIndex).GetRole())){
                   totalPay = Employees.get(EmployeeIndex).GetSalary()+ totalPay;
               }

            }
            if(CalculateByTime == Boolean.FALSE)
            System.out.println("total pay of all "+Roles.get(RoleIndex)+" is "+totalPay);
            else{
                System.out.println("total pay of all "+Roles.get(RoleIndex)+" pre year day "+totalPay/365+" pre month is "+totalPay/12);
            }
            totalPay=0;
        }

    }


    void CalculateTotalPay(Boolean CalculateByTime){
        int totalpay=0;

        for(int EmployeeIndex = 0;EmployeeIndex<Employees.size();EmployeeIndex++){
            totalpay = Employees.get(EmployeeIndex).GetSalary() + totalpay;
        }

        if(CalculateByTime == Boolean.FALSE)
            System.out.println("total pay of all employees is "+totalpay);
        else{
            System.out.println("total pay of all employees pre year day "+totalpay/365+" pre month is "+totalpay/12);
        }
    }


}
    public class Main {

        public static void main(String[] args) {

            //new employee("david","6000","software");

            String option;
            String filename;

            if (args.length == 2) {
                filename = args[0];
                option = args[1];
            } else {
                System.out.println("Invalid arguments size of " + args.length + " expecting 2");
                return;
            }

            employeeCalculations calculation = new employeeCalculations(filename);

            switch (option.charAt(0)) {
                case 'a':
                    calculation.CalculateTotalPay(false);
                    break;
                case 'b':
                    calculation.CalculatePayByRole(false);
                    break;
                case 'c':
                    calculation.CalculateTotalPay(true);
                    break;
                case 'd':
                    calculation.CalculatePayByRole(true);
                    break;
                default:
                    System.out.println("Invalid command please try again");
                    break;


            }
        }
    }
