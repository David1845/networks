function displayBeers( ){
	var beerType = document.getElementById('beerType').value;
	var i;
	var text = "";

	for(i =99; i>-1;i--){
		text = text+i+" "+"bottles of "+beerType+" on the wall"+"</br>";
	}
	document.getElementById('NumBeersOnTheWall').innerHTML += text;
	
}