package com.company;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

class employeeCaluclations{

    private ArrayList<employee> Data;
    private ArrayList<String> Roles;
    private String Filename;



    employeeCaluclations(String Filename){
        this.Filename= Filename;
        readfile();
    }

// readfile(): reads in the csv line by line and adds each line to an ArrayList of Employee Objects.

    private void readfile(){
        this.Data = new ArrayList<employee>();
        Scanner s = null;
        try {
            s = new Scanner(new File(Filename));
            s.nextLine();
            while (s.hasNext()){

                // calls the employee class and fills the ArrayList of employees

                this.Data.add(new employee(s.nextLine()));
            }
            s.close();
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

/// CalculateTotalPay: adds up every employees pay into one sum.

    void CalculateTotalPay(Boolean CalculateByTime){
        int totalpay=0;
        for(int CustomerIndex=0;CustomerIndex<this.Data.size();CustomerIndex++)
            totalpay = Integer.parseInt(this.Data.get(CustomerIndex).employeeData.get(1)) + totalpay;

        if(CalculateByTime == Boolean.FALSE)
            System.out.println("The total pay of all employees is "+totalpay);
        else{
            System.out.println("total pay of all employees per day is "+totalpay/365+" per month is "+totalpay/12+" and total pay per year "+totalpay);
        }
    }


// get_roles: iterates through every roles and adds it the the array list role.
// if the role already exist it will not be added

    private void get_roles(){
        int Rolefound =0;

        for(int j=0;j<Data.size();j++) {

            for (int i = 0; i < Roles.size(); i++) {

                if(Roles.get(i).equals(Data.get(j).employeeData.get(2))){
                    Rolefound =1;
                }

            }

            if(Rolefound==0){
                Roles.add(Data.get(j).employeeData.get(2));
            }

            Rolefound=0;
        }
    }


// CalculateTotalPay: computes total salary sum for each employee with respect to roll.

    void CaluclatePayByRole(Boolean CalculateByTime){
        Roles = new ArrayList<String>();

        get_roles();
        int totalPay=0;

        // iterates though each role and compares it to every employee role found

        for(int RoleIndex =0; RoleIndex < Roles.size(); RoleIndex++){

            for(int EmployeeIndex = 0; EmployeeIndex < Data.size(); EmployeeIndex ++){

                if(Roles.get(RoleIndex).equals(Data.get(EmployeeIndex).employeeData.get(2))) {

                    totalPay = Integer.parseInt(Data.get(EmployeeIndex).employeeData.get(1)) + totalPay;
                }

            }

            //

            if(CalculateByTime == Boolean.FALSE)
                System.out.println("total pay of all "+Roles.get(RoleIndex)+" is "+totalPay);
            else{
                System.out.println("total pay of all "+Roles.get(RoleIndex)+"s: is "+totalPay/365+" per day, "+totalPay/12+" per month and total pay per year is "+totalPay);
            }
            totalPay = 0;
        }
    }

}


class employee{

    private String employeeInfo;
    public ArrayList<String> employeeData;

    employee(){

    }


    employee(String employeeInfo){
        this.employeeInfo = employeeInfo;
        setEmployeeData();
    }

// setEmployeeData: parses each line of employee data by a ',' Delimiter, and adds the data to an ArrayList employeeData

    private void setEmployeeData(){
        //System.out.println(employeeInfo);
        this.employeeData = new ArrayList<String>();

        Scanner s = new Scanner(this.employeeInfo).useDelimiter(",");

        while (s.hasNext()) {
            this.employeeData.add(s.next());
        }

        s.close();

    }

}


public class Main {

    public static void main(String[] args) {

        String filename;
        String option;


        if(args.length==2){
             filename =args[0];
             option = args[1];
        }else{
            System.out.println("Invalid arguments size of "+args.length+" expecting 2");
            return;
        }

        switch (option.charAt(0)){
            case 'a':
                new employeeCaluclations(filename).CalculateTotalPay(Boolean.FALSE);
                break;
            case 'b' :
                new employeeCaluclations(filename).CaluclatePayByRole(Boolean.FALSE);
                break;
            case 'c':
                new employeeCaluclations(filename).CalculateTotalPay(Boolean.TRUE);
                break;
            case 'd':
                new employeeCaluclations(filename).CaluclatePayByRole(Boolean.TRUE);
                break;
            default:
                System.out.println("Invalid command please try again");
                break;

        }


    }
}
